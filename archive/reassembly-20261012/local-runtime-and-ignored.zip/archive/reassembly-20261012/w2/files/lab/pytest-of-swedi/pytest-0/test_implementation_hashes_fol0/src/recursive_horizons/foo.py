from . import bar
value = bar.value
